import vue from 'rollup-plugin-vue'

export default {
  process: {},
  input: "",
  plugins: [vue(/* options */)],
  output: {
    dir: "",
  }
};